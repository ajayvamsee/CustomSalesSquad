package com.example.customsalessquad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Login_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__screen);
    }
}